package display;

import java.util.Vector;

import contentprovider.Clock;
import contentprovider.ContentProvider;
import contentprovider.Message;

public class DisplayManager {
	
	private static DisplayManager _instance = null; //singelton
	private Screen screen;
	private Vector<ContentProvider> contents;
	
	private DisplayManager() {
		screen = new Screen();
		contents = new Vector<ContentProvider>();
	}
	
	public static DisplayManager getInstance(){
		if(_instance == null){
			_instance = new DisplayManager();
		}
		
		return _instance;
	}
	
	public void addClock(){
		contents.add(new Clock());
	}
	
	public void addMessage(){
		contents.add(new Message());
	}
	
	public void display(){
		for(ContentProvider c : contents)
		{
			screen.display(c.getContent());
		}
	}

}
