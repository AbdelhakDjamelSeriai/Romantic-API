package display;

public class Screen {

	public Screen() {
		// TODO Auto-generated constructor stub
	}
	
	public void display(String content)
	{
		System.out.println(content);
	}
}
