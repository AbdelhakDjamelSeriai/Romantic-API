package contentprovider;

public interface IContentProvider {
	public String getContent();
}
