package contentprovider;

public class GPS {
	protected long longitude;
	protected long latitude;
	
	public GPS() {
		// set possition
	}
	
	public long getLatitude() {
		return latitude;
	}
	
	public long getLongitude() {
		return longitude;
	}
}
