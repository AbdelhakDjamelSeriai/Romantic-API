package contentprovider;

public class Message extends ContentProvider{
	
	public Message() {
		content = "Current Time";
	}
	
	@Override
	public String getContent() {
		return super.getContent();
	}

}
