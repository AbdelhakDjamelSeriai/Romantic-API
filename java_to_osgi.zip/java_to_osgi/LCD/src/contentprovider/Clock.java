package contentprovider;


public class Clock extends ContentProvider{
	
	public Clock() {
		TimeZone timeZone = new TimeZone(new GPS());
		content = timeZone.getTime().toString() + " -> GPS " + timeZone.gps.getLatitude() + "," + timeZone.gps.getLatitude();
	}

	@Override
	public String getContent() {
		return super.getContent();
	}
}
