package contentprovider;

import java.util.Date;

public class TimeZone {
	
	Date time;
	protected GPS gps;
	
	public TimeZone(GPS gps) {
		this.gps = gps;
		time = new Date(System.currentTimeMillis());
	}
	
	public Date getTime() {
		return time;
	}

}
