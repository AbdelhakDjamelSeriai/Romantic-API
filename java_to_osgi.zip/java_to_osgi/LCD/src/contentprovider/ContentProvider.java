package contentprovider;


public abstract class ContentProvider implements IContentProvider{
	
	protected String content = "";	
	
	public ContentProvider() {
	}
	
	public String getContent() {
		return content;
	}

}
