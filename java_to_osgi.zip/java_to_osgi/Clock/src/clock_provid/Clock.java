package clock_provid;

import timezone_provid.IGPS;
import timezone_provid.ITimeZone;

public class Clock implements IClock{
	
	private ITimeZone timeZone;
	private IGPS GPS;
	String content;

	public Clock() {
	}

	@Override
	public String getContent() {
		return content;
	}

	public synchronized void setTimeZone(ITimeZone iTimeZone) {

		timeZone = iTimeZone;
		timeZone.setParameters(GPS);
		timeZone.constructor();
//		System.out.println("setTimeZone = " + iTimeZone.getTime().toString());
		IGPS iGPS = timeZone.getGPS();
		content = timeZone.getTime().toString() + " -> GPS " + iGPS.getLatitude() + "," + iGPS.getLatitude();
	}

	public synchronized void unSetTimeZone() {
		timeZone = null;
	}

	public synchronized void setGPS(IGPS iGPS) {
//		System.out.println("setGPS = " + iGPS.getLatitude() + " , "
//				+ iGPS.getLongitude());
		GPS = iGPS;
	}

	
	public synchronized void unSetGPS() {
		GPS = null;
	}
	
}


