package clock_provid;

import contentprovider_provid.IContentProvider;

public interface IClock extends IContentProvider{
	
	public String getContent();

}
