package timezone_provid;

import java.util.Date;

import timezone_core.GPS;

public interface ITimeZone {
	
	public Date getTime();
	
	public void setParameters(IGPS gps);
	public void constructor();
	
	public IGPS getGPS();

}
