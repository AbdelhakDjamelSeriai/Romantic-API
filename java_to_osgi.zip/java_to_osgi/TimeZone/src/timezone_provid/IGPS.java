package timezone_provid;

public interface IGPS {
	
	public void setLatitude(long latitude);
	public long getLatitude();
	public void setLongitude(long Longitude);
	public long getLongitude();
	
	

}
