package timezone_core;

import java.util.Date;

import timezone_provid.IGPS;
import timezone_provid.ITimeZone;

public class TimeZone implements ITimeZone{
	
	private Date time;
	private IGPS gps;
	
	public TimeZone() {

	}
	
	public TimeZone(GPS gps) {
//		System.out.println("GPS = "+gps.getLatitude() + "," + gps.getLongitude());
		time = new Date(System.currentTimeMillis());
	}
	
	public Date getTime() {
		return time;
	}
	
	//must be called after Instantiating object
	public void setParameters(IGPS gps){
		this.gps = gps;
	}
	
	
	//must be called after setParameter method
	public void constructor(){
//		System.out.println("GPS = "+gps.getLatitude() + "," + gps.getLongitude());
		time = new Date(System.currentTimeMillis());
	}
	
	public IGPS getGPS(){
		return gps;
	}

}
