package timezone_core;

import timezone_provid.IGPS;

public class GPS implements IGPS{
	protected long longitude;
	protected long latitude;
	
	public GPS() {
		// set possition
	}
	
	@Override
	public void setLatitude(long latitude) {
		this.latitude = latitude;
	}
	
	@Override
	public long getLatitude() {
		return latitude;
	}
	
	@Override
	public void setLongitude(long Longitude) {
		this.longitude = Longitude;
	}
	
	@Override
	public long getLongitude() {
		return longitude;
	}
}
