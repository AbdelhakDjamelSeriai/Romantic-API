package contentprovider_provid;

public interface IContentProvider {
	
	public String getContent();

}
