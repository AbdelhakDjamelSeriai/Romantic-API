package lcd_display_provid;

import java.util.Vector;

import contentprovider_provid.IContentProvider;
import message_provid.IMessage;
import clock_provid.IClock;



public class DisplayManager {
	
	private static DisplayManager _instance = null; //singelton
	private Screen screen;
	private Vector<IContentProvider> contents;
	private IContentProvider contentProvider;
	
	public DisplayManager() {
		screen = new Screen();
		contents = new Vector<IContentProvider>();
	}
	
	public static DisplayManager getInstance(){
		if(_instance == null){
			
			_instance = new DisplayManager();
		}
		
		return _instance;
	}
	
	public void addContent(IContentProvider contentProvider){
//		System.out.println("add content => "+contentProvider);
		contents.add(contentProvider);
	}
	
	public void display(){
		for(IContentProvider c : contents)
		{
			if(c == null)
			System.out.println("display out of service :(");
			else
			screen.display(c.getContent());
		}
	}
	
	public synchronized void setClock(IClock iClock){
//		System.out.println("setClock(IClock iClock)");
		DisplayManager.getInstance().addContent(iClock);
		DisplayManager.getInstance().display();
	
		
	}
	
	public synchronized void unSetClock(){

	}
	
	public synchronized void setMessage(IMessage iMessage){
//		System.out.println("setMessage(IMessage iMessage)");
		DisplayManager.getInstance().addContent(iMessage);
	}
	
	public synchronized void unSetMessage(){
		
	}
	
	public synchronized void setContentProvider(IContentProvider iContentProvider){
		System.out.println("setContentProvider(IContentProvider iContentProvider)");
	}
	
	public synchronized void unSetContentProvider(IContentProvider iContentProvider){
		
	}
	

}
