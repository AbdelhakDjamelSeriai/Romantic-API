package lcd_display_provid;

public class Screen {

	public Screen() {
		// TODO Auto-generated constructor stub
	}
	
	public void display(String content)
	{
		System.out.println(content);
	}
}
