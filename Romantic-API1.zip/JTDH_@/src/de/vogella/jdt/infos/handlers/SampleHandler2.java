
package de.vogella.jdt.infos.handlers;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.ui.handlers.HandlerUtil;

import romantic.ComponentsIdentificationMain;
public class SampleHandler2 extends AbstractHandler {
	
public Object execute(ExecutionEvent event) throws ExecutionException {
	
	// Get the root of the workspace
				IWorkspace workspace = ResourcesPlugin.getWorkspace();
				IWorkspaceRoot root = workspace.getRoot();
				// Get all projects in the workspace
				DirectoryDialog fileDialog = new DirectoryDialog(HandlerUtil.getActiveShell(event));
				String directory = fileDialog.open();
				IProject[] projects = root.getProjects();
				for (IProject project : projects) {
					try {
						if (project.isNatureEnabled("org.eclipse.jdt.core.javanature") && project.isOpen()) {
							IJavaProject javaProject = JavaCore.create(project);
							
							//D:\Study\EclipseWarkSpace\test
							String file = "D:/Study/EclipseWarkSpace/test";//javaProject.getPath().makeAbsolute().toString();
							
							
							ComponentsIdentificationMain.main(file);
							if (directory!=null) {
								// write results
							}	
						}
					}catch (JavaModelException e) {
						e.printStackTrace();
					} catch (CoreException e) {
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
	
	return null;
	}

}
