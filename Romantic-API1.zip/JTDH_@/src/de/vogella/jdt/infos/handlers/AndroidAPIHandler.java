
package de.vogella.jdt.infos.handlers;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.Comment;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.IBinding;
import org.eclipse.jdt.core.dom.IMethodBinding;
import org.eclipse.jdt.core.dom.ITypeBinding;
import org.eclipse.jdt.core.dom.IVariableBinding;
import org.eclipse.jdt.core.dom.LineComment;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.BodyDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.osgi.internal.resolver.ComputeNodeOrder;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.handlers.HandlerUtil;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

import dataMining.pattern.AprioriAlgo;
import romantic.ComponentNaming;
import romantic.clustering.BinaryTree;
import romantic.clustering.ClusteringUtils;
import romantic.clustering.ExtractPotentialComponent;
import romantic.clustering.methods.MethodsBinaryTree;
import romantic.clustering.methods.MethodsClusteringUtils;
import romantic.geneticalgorithm.GeneticAlgorithmUtils;
import romantic.metamodel.APIAttribute;
import romantic.metamodel.APIMethod;
import romantic.metamodel.Attribute;
import romantic.metamodel.Clazz;
import romantic.metamodel.Method;
import romantic.metamodel.OOSystem;
import romantic.metrics.Metrics;
import romantic.parsing.Util;
import visitors.FieldAccessVisitor;
import visitors.MethodInvocationVisitor;
import visitors.TypeDeclarationVisitor;
import visitors.VariableDeclarationFragmentVisitor;
import visitors.LineCommentVisitor;

public class AndroidAPIHandler extends AbstractHandler {
	public static final String API_NAME = "android";
	
	public static double minSupport = -1.0;
	public static int totalNoComponants = 0;
	public static int totalNoProjects = 0;
	public static int totalNoTransactions = 0;
	public static int totalTransactionsSize = 0;
	public static int totalNoPatterns = 0;
	public static int totalPatternSize = 0;
	public static int totalNoClasses = 0;
	public static int totalNoAPIClasses = 0;
	
	public static int totalNoInterfaces = 0;
	public static int totalInterfacesSize = 0;
	
	public static int totalNoAPIComponants = 0;
	public static int totalAPIComponantsSize = 0;
	
	public static String projectsNames = "";
	public static final String END_ROWS = "\\\\ \\hline";
	public static final String END_CELL = " & ";
	public static final int COLOMN_NO = 5;
	public static int projectNO = 0;
	
	
	
@SuppressWarnings("unchecked")
public Object execute(ExecutionEvent event) throws ExecutionException {
	setMinSupport(event);
		return null;
	}

public void setMinSupport(final ExecutionEvent event){
	
	final Shell shell = new Shell(Display.getCurrent());
	shell.setText("Min Support Value Between [0.0 - 1.0]");
	shell.setLayout(new GridLayout());
	shell.setSize(400, 300);
	final Text text = new Text(shell, SWT.SINGLE | SWT.BORDER);
	GridData layoutData= new GridData(GridData.FILL_HORIZONTAL);
	text.setLayoutData(layoutData);
	Button button = new Button(shell, SWT.PUSH);
	button.setText("Set");
	button.addSelectionListener(new SelectionListener() {
		
	@Override
	public void widgetSelected(SelectionEvent e) {
		minSupport = Double.parseDouble(text.getText());
		shell.close();
		parse(event);
	}
	@Override
	public void widgetDefaultSelected(SelectionEvent e) {
	}
	});
	shell.layout();
	shell.open();
}

public void parse(ExecutionEvent event){
	//zax
	OOSystem oosystem;
	OOSystem oosystemAPI = new OOSystem();
	
	Set<Set<String>> transactions = new HashSet<Set<String>>();
	Set<Set<String>> frequentPatterns = new HashSet<Set<String>>();
	Set<Set<Clazz>> componentsAPI = new HashSet<Set<Clazz>>();
		
		boolean isFileCreated = false;
		
		
//		int packagesNum=0;
		int classesNum=0;
//		int methodsNum=0;
//		int AttributesNum=0;
//	    int countClassNumber = 0;
			// Get the root of the workspace
			IWorkspace workspace = ResourcesPlugin.getWorkspace();
			IWorkspaceRoot root = workspace.getRoot();
			// Get all projects in the workspace
			DirectoryDialog fileDialog = new DirectoryDialog(HandlerUtil.getActiveShell(event));
			String directory = fileDialog.open();
			IProject[] projects = root.getProjects();
			for (IProject project : projects) {
				try {
					if (project.isNatureEnabled("org.eclipse.jdt.core.javanature") && project.isOpen()) {
						oosystem = new OOSystem();
						//set reference
						OOSystem oosystemControler = null;
						if(project.getName().equals("API")){
							oosystemControler = oosystemAPI;
						}else{
							oosystemControler = oosystem;
						}
						
						boolean isUsedAPI = false;
						
						
						IJavaProject javaProject = JavaCore.create(project);
						Element xmlroot = new Element("Project");
						Document doc = new Document(xmlroot);
						xmlroot.setAttribute("ProjectName", javaProject.getElementName());
						Element xmlPackages = new Element("Packages");
						xmlroot.addContent(xmlPackages);
						for (IPackageFragment packageFragment : javaProject.getPackageFragments()) {
							if (packageFragment.getKind() == IPackageFragmentRoot.K_SOURCE && !packageFragment.getElementName().equals("")) {
								Element xmlPackage = new Element("Package");
								xmlPackages.addContent(xmlPackage);
								xmlPackage.setAttribute("PackageName", packageFragment.getElementName());
//								++packagesNum;
								Element xmlClasses = new Element("Classes");
								xmlPackage.addContent(xmlClasses);
								for (ICompilationUnit compilationUnit : packageFragment.getCompilationUnits()) {
										ASTParser parser = ASTParser.newParser(AST.JLS4);
										parser.setSource(compilationUnit);
										parser.setKind(ASTParser.K_COMPILATION_UNIT);
										parser.setEnvironment(null, new String[]{"D:/Study/EclipseWarkSpace"}, null, false);
										parser.setProject(javaProject);
										parser.setResolveBindings(true);
										parser.setBindingsRecovery(true);
										final CompilationUnit cu = (CompilationUnit) parser.createAST(null);
										TypeDeclarationVisitor typeDeclarationVisitor = new TypeDeclarationVisitor();
										cu.accept(typeDeclarationVisitor);
										
										for (TypeDeclaration typeDeclaration : typeDeclarationVisitor.getTypes()) {
											Element xmlClass = new Element("Class");
											xmlClasses.addContent(xmlClass);
											xmlClass.setAttribute("ClassName", typeDeclaration.getName().getFullyQualifiedName());
											
											++classesNum;
											if (Modifier.isPublic(typeDeclaration.resolveBinding().getModifiers())) {
												xmlClass.setAttribute("classAccessLevel", "public");
											} else
											if (Modifier.isProtected(typeDeclaration.resolveBinding().getModifiers())) {
												xmlClass.setAttribute("classAccessLevel", "protected");
											} else
											if (Modifier.isPrivate(typeDeclaration.resolveBinding().getModifiers())) {
												xmlClass.setAttribute("classAccessLevel", "private");
											}				
											xmlClass.setAttribute("isInterface",String.valueOf(typeDeclaration.isInterface()));
																				
											if (typeDeclaration.resolveBinding().getSuperclass()!=null) 
											{
												xmlClass.setAttribute("Superclass",typeDeclaration.resolveBinding().getSuperclass().getPackage().getName()+"@"+typeDeclaration.resolveBinding().getSuperclass().getName());
											}
											else 
												xmlClass.setAttribute("Superclass","");
											
											//zax
											String classFullName = typeDeclaration.resolveBinding().getQualifiedName();
											Clazz clazz = oosystemControler.getClazzByName(classFullName);
											if (clazz==null) {
												clazz = new Clazz(typeDeclaration.resolveBinding().getQualifiedName());
												oosystemControler.add(clazz);
											}
											
											Element xmlInterfaces = new Element("SuperInterfaces");
											xmlClass.addContent(xmlInterfaces);
											
											for (ITypeBinding itf : typeDeclaration.resolveBinding().getInterfaces()) {
												Element xmlInterface = new Element("Interface");
												xmlInterfaces.addContent(xmlInterface);
												xmlInterface.setAttribute("InterfaceName",itf.getName());
											}
											Element xmlFields = new Element("Attributes");
											xmlClass.addContent(xmlFields);
											
											for (FieldDeclaration fieldDeclaration : typeDeclaration.getFields()) {
												
												for (VariableDeclarationFragment variable : (List<VariableDeclarationFragment>)fieldDeclaration.fragments()) {
													Element xmlField = new Element("Attribute");
													xmlFields.addContent(xmlField);
//													++AttributesNum;
													xmlField.setAttribute("AttributeName", variable.getName().getFullyQualifiedName());
													
													//System.out.println(variable.resolveBinding().getModifiers());
													if (variable.resolveBinding()!=null)
													{
													
											    	if (Modifier.isPublic(variable.resolveBinding().getModifiers())) 
													{
														xmlField.setAttribute("AttributeAccessLevel", "public");
													} else
													if (Modifier.isProtected(variable.resolveBinding().getModifiers())) 
													{
														xmlField.setAttribute("AttributeAccessLevel", "protected");
													} else
													if (Modifier.isPrivate(variable.resolveBinding().getModifiers())) 
													{
														xmlField.setAttribute("AttributeAccessLevel", "private");
													}
											    	
														
												  
													xmlField.setAttribute("AttributeType", variable.resolveBinding().getType().getName());
													xmlField.setAttribute("isStaticAttribute",String.valueOf(Modifier.isStatic(variable.resolveBinding().getModifiers())));
													xmlField.setAttribute("AttributFullPath", typeDeclaration.resolveBinding().getPackage().getName()+"@"+typeDeclaration.resolveBinding().getName()+"@"+variable.getName().getFullyQualifiedName());
													
													}
												}	
											}
											Element xmlMethods = new Element("Methods");
											xmlClass.addContent(xmlMethods);
											for (MethodDeclaration methodDeclaration : typeDeclaration.getMethods()) {
												Element xmlMethod = new Element("Method");
												xmlMethods.addContent(xmlMethod);
//												++methodsNum;
												if(methodDeclaration.resolveBinding() == null){continue;}
												xmlMethod.setAttribute("MethodName",classFullName + "." + methodDeclaration.resolveBinding().getName());
												
												//zax
												boolean isPublic = false;
												
												if (Modifier.isPublic(methodDeclaration.resolveBinding().getModifiers())) {
													xmlMethod.setAttribute("MethodAccessLevel", "public");
													isPublic = true;
												} else
												if (Modifier.isProtected(methodDeclaration.resolveBinding().getModifiers())) {
													xmlMethod.setAttribute("MethodAccessLevel", "protected");
												} else
												if (Modifier.isPrivate(methodDeclaration.resolveBinding().getModifiers()))
												{
													xmlMethod.setAttribute("MethodAccessLevel", "private");
												}
												//else
											
												if(methodDeclaration.getBody()!=null)
												{
												xmlMethod.setAttribute("MethodBody",methodDeclaration.getBody().statements().toString());//  .statements().toString());
												}
														
												xmlMethod.setAttribute("MethodReturnType",methodDeclaration.resolveBinding().getReturnType().getName());
												xmlMethod.setAttribute("isStaticMethod",String.valueOf(Modifier.isStatic(methodDeclaration.resolveBinding().getModifiers())));
												
												//zax
												String methodFullName = classFullName + "." + methodDeclaration.resolveBinding().getName();
												Method method = clazz.getMethodByName(methodFullName);
												if (method==null) {
													method = new Method(methodDeclaration.resolveBinding().getName(),clazz);
													method.setPublicFlag(isPublic);
													clazz.addMethod(method);
												}
												
												Element xmlParameters = new Element("Parameters");
												xmlParameters.setAttribute("NumberOfParameters", String.valueOf(methodDeclaration.parameters().size()));
												xmlMethod.addContent(xmlParameters);
												for (SingleVariableDeclaration singleVariableDeclaration : (List<SingleVariableDeclaration>)methodDeclaration.parameters()) {
													Element xmlParameter = new Element("Parameter");
													xmlParameters.addContent(xmlParameter);
													xmlParameter.setAttribute("ParameterName", singleVariableDeclaration.getName().getFullyQualifiedName());
													xmlParameter.setAttribute("ParameterType", singleVariableDeclaration.resolveBinding().getType().getName());
												}
												
												Element xmlVariableDeclarations = new Element("LocalVariables");
												xmlMethod.addContent(xmlVariableDeclarations);
												VariableDeclarationFragmentVisitor variableDeclarationFragmentVisitor = new VariableDeclarationFragmentVisitor();
												methodDeclaration.accept(variableDeclarationFragmentVisitor);
												for (VariableDeclarationFragment variableDeclarationFragment : variableDeclarationFragmentVisitor.getVariables()) {
												    if(variableDeclarationFragment.resolveBinding()!=null){
												    variableDeclarationFragment.resolveBinding().getName();
													Element xmlVariableDeclaration = new Element("LocalVariable");
													xmlVariableDeclarations.addContent(xmlVariableDeclaration);
													xmlVariableDeclaration.setAttribute("LocalVariableName", variableDeclarationFragment.getName().toString());
													xmlVariableDeclaration.setAttribute("LocalVariableType", variableDeclarationFragment.resolveBinding().getType().getName());
												    }
												}
												
												
												
												Element xmlMethodInvocations = new Element("MethodInvocations");
												xmlMethod.addContent(xmlMethodInvocations);
												MethodInvocationVisitor methodInvocationVisitor = new MethodInvocationVisitor();
												methodDeclaration.accept(methodInvocationVisitor);
												
												for (MethodInvocation methodInvocation : methodInvocationVisitor.getMethods())
												{
										
													//zax
													String calledClassName = "";
													String calledMethodName;
													
													Element xmlMethodInvocation = new Element("MethodInvocation");
													
													IMethodBinding methodBinding = methodInvocation.resolveMethodBinding();
													if (methodBinding!=null){
												   // if (methodInvocation.resolveTypeBinding()!=null &&  methodInvocation.resolveTypeBinding().getDeclaringClass()!=null && methodInvocation.resolveTypeBinding().getDeclaringClass().getName()!=null)
														calledClassName = methodInvocation.resolveMethodBinding().getDeclaringClass().getPackage().getName()+"."+methodInvocation.resolveMethodBinding().getDeclaringClass().getName();
														if(calledClassName.startsWith("java")){
															continue;
														}

														xmlMethodInvocation.setAttribute("DeclaredClass", calledClassName);
													} else {
												       	//xmlMethodInvocation.setAttribute("DeclaredClass",methodInvocation.getName().toString());   
													    xmlMethodInvocation.setAttribute("DeclaredClass","");
													}
													
													if (!methodInvocation.getName().toString().equals("println") && !methodInvocation.getName().toString().equals("print") && !(methodInvocation.arguments().toString().length()>=40))
													{
														
													xmlMethodInvocations.addContent(xmlMethodInvocation);
													//zax
													calledMethodName = methodInvocation.getName().toString();
													xmlMethodInvocation.setAttribute("MethodInvocationName", calledMethodName);
													xmlMethodInvocation.setAttribute("AccessedIn",methodInvocation.arguments().toString());

													//zax
													String calledMethodFullName = calledClassName + "." + calledMethodName;
													Clazz calledClazz = oosystemControler.getClazzByName(calledClassName);
													Method calledMethod = null;
													APIMethod calledMethodAPI = null;
													
													if (calledClazz==null) {
														calledClazz = new Clazz(calledClassName);
														if(calledClassName.startsWith("java")){
															continue;
														}else if(calledClassName.startsWith(API_NAME)){
															isUsedAPI = true;
															oosystemAPI.add(calledClazz);
															calledMethodAPI = new APIMethod(calledMethodFullName, calledClazz);
														}else{
															oosystemControler.add(calledClazz);
															calledMethod = new Method(calledMethodFullName, calledClazz);
//															calledMethod.setPublicFlag(isPublic);
															calledClazz.addMethod(calledMethod);
														}
														
													} else {
														calledMethod = calledClazz.getMethodByName(calledMethodFullName);
														if (calledMethod==null) {
															calledMethod = new Method(calledMethodFullName, calledClazz);
//															calledMethod.setPublicFlag(isPublic);
															calledClazz.addMethod(calledMethod);
														}
													}
													
													if(calledClassName.startsWith(API_NAME)){
														isUsedAPI = true;
														method.addCalledAPIMethod(calledMethodAPI);
													}else{
														method.addCalledMethod(calledMethod);
													}
													
												}
												}
												

												Element xmlFieldAccesses = new Element("FieldAccesses");
												xmlMethod.addContent(xmlFieldAccesses);
												FieldAccessVisitor fieldAccessVisitor = new FieldAccessVisitor();
												methodDeclaration.accept(fieldAccessVisitor);
												for (SimpleName fieldName : fieldAccessVisitor.getFields())
												{
													
													if(!fieldName.toString().contains("out") && !fieldName.toString().contains("err"))	
													{
														//zax
														String variableBindingClassName = "";
														String variableBindingName = "";
														
													Element xmlFieldAccess = new Element("FieldAccess");
													xmlFieldAccesses.addContent (xmlFieldAccess);
													xmlFieldAccess.setAttribute("FieldAccessName", fieldName.toString());
													//zax
													variableBindingName = fieldName.toString();
													
													IVariableBinding variableBinding = (IVariableBinding) fieldName.resolveBinding();
													if(variableBinding!=null)
													{
														if (variableBinding.getDeclaringClass()!=null ){
															variableBindingClassName = variableBinding.getDeclaringClass().getPackage().getName()+"."+variableBinding.getDeclaringClass().getName();
															 xmlFieldAccess.setAttribute("FieldDeclared", variableBindingClassName);
															 
															//zax
																String variableBindingFullName = variableBindingClassName + "." + variableBindingName;
																Clazz calledClazz = oosystemControler.getClazzByName(variableBindingClassName);
																
																Attribute accessedAttribute = null;
																APIAttribute accessedAPIAttribute = null;
																
																if (calledClazz==null) {
																	calledClazz = new Clazz(variableBindingClassName);
																	if(variableBindingFullName.startsWith("java")){
																		accessedAttribute = new Attribute(variableBindingFullName, calledClazz);
																	}else if(variableBindingFullName.startsWith(API_NAME)){
																		isUsedAPI = true;
																		oosystemAPI.add(calledClazz);
																		accessedAPIAttribute = new APIAttribute(variableBindingFullName, calledClazz);
																	}else{
																		oosystemControler.add(calledClazz);
																		accessedAttribute = new Attribute(variableBindingFullName, calledClazz);
																		calledClazz.addAttribute(accessedAttribute);
																	}
																	
																} else {
																	// la classe existe dans le systeme
																	accessedAttribute = calledClazz.getAttributeByName(variableBindingFullName);
																	if (accessedAttribute==null) {
																		accessedAttribute = new Attribute(variableBindingFullName, calledClazz);
																	calledClazz.addAttribute(accessedAttribute);
																	}
																}
																
																if(variableBindingFullName.startsWith(API_NAME)){
																	isUsedAPI = true;
																	method.addAPIAccessedAttribute(accessedAPIAttribute);
																}else{
																	method.addAccessedAttribute(accessedAttribute);
																}
																
																
															 
														}else
															 //xmlFieldAccess.setAttribute("FieldDeclared", fieldName.toString());	
														     xmlFieldAccess.setAttribute("FieldDeclared", "");
													}
													   else
														  // xmlFieldAccess.setAttribute("FieldDeclared", fieldName.toString());	
														   xmlFieldAccess.setAttribute("FieldDeclared", "");
													}	
												
												}
												

												Element xmlMethodExceptions = new Element("MethodExceptions");
												xmlMethod.addContent(xmlMethodExceptions);
												for (ITypeBinding exceptions : methodDeclaration.resolveBinding().getExceptionTypes()) {
													Element xmlMethodException = new Element("Exception");
													xmlMethodExceptions.addContent(xmlMethodException);
													xmlMethodException.setAttribute("ExceptionType", exceptions.getName());	
												}
											}
										}	
								}
							}
						}
						

						if(project.getName().equals("API")){
							totalNoAPIClasses = oosystemAPI.getClazzes().size();
							continue;
							}
						if(isUsedAPI)
						{
						String classesNumber=Integer.toString(classesNum);
						
						Element xmlProjectDetails = new Element("xmlProjectInfo");
//						
						xmlroot.addContent(xmlProjectDetails);
						xmlProjectDetails.setAttribute("NumberofClasses", classesNumber);
						
						//Write results
						if(!isFileCreated){
						Date date = new Date();
						directory += "/" + " results "+date.getDate() + " " + date.getTime();
						File file = new File(directory);
						file.mkdir();
						isFileCreated = true;
						}
						if (directory!=null) {
							XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
							outputter.output(doc, new FileOutputStream(directory + "/" + project.getName() + " parser.xml"));	
							classesNum = 0;
						}
						
						

						
						//Apply ROMANTIC
						//Identify components
//						BinaryTree binaryTree = ClusteringUtils.clustering(oosystem.getClazzes());
//						Set<Set<Clazz>> clusters = ClusteringUtils.parcoursDendrogramme(binaryTree,0.5);
						
						
						//Genetic algorithem
						Set<Set<Clazz>> clusters = null;
						List<Set<Set<Clazz>>> population = GeneticAlgorithmUtils
								.initialPopulation(oosystem.getClazzes(), 25);
						for (int i = 0; i < 25; i++) {
							population = GeneticAlgorithmUtils.selection1(population);
							GeneticAlgorithmUtils.croisement(population);
							GeneticAlgorithmUtils.mutationPopulation(population, 0.5);
							population = GeneticAlgorithmUtils.selection2(population, 25);

							// System.in.read();
							if (population.isEmpty())
								break;
							clusters = GeneticAlgorithmUtils.bestChromosome(population);
							GeneticAlgorithmUtils.fChromosomeComposant(clusters);
						}

						
						
						//Identify Transaction
						Set<String> transaction = new HashSet<String>();
						for(Set<Clazz> cluster : clusters)
						{
							for(Clazz clazz : cluster)
							{
								for(Method method : clazz.getMethods())
								{
									for(APIMethod methodInvocation : method.getAPICalledMethods())
									{
										transaction.add(methodInvocation.getClazz().getName());
									}
								}
							}
							
							totalTransactionsSize += transaction.size();
							if(transactions.add(transaction)){
								totalNoTransactions ++;
							}
						}
						
						
							totalNoProjects ++;
							totalNoComponants += clusters.size();
							totalNoClasses += oosystem.getClazzes().size();
						
						
												
						//Write results
						try {
							ClusteringUtils.printClusters(clusters, new PrintStream(new FileOutputStream(directory + "/" + project.getName() +  " clusters.txt")));
						} catch (FileNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						//consol results
						System.out.println("Nombre de classes : " + oosystem.getClazzes().size());
						//Nombre de clusters
						System.out.println("Nombre de clusters : " + clusters.size());
						double moyenne = oosystem.getClazzes().size();
						moyenne /= clusters.size();
						System.out.println("Nombre moyen de classes par clusters : " + moyenne);
						//Nombre maximale de classes par clusters
						int max = 0;
						for (Set<Clazz> cluster : clusters) {
							if (cluster.size()>max) {
								max = cluster.size();
							}
						}
						System.out.println("Nombre maximal de classes par clusters : " + max);
						}
						
						
						
					}//end if
				} //end try
				
				catch (FileNotFoundException e) {
				e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} catch (JavaModelException e) {
					e.printStackTrace();
				} catch (CoreException e) {
					e.printStackTrace();
				}
				
				if(projectNO != 0 && projectNO % COLOMN_NO == 0)
				{
					projectsNames += project.getName() + END_ROWS;
				}else{
					projectsNames += project.getName() + END_CELL;
				}
				
				projectNO++;
				System.out.println("projectNO = " + projectNO);
				

			}//end loop project
			
			
			//print projects name
			try {
				printProjectsName(new PrintStream(new FileOutputStream(directory + "/ projects name.txt")));
				printStatisticsPhase1(new PrintStream(new FileOutputStream(directory + "/" + " Statistics Phase1.txt")));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			oosystem = null;
			System.gc();
			
			//get frequent patterns
			frequentPatterns.addAll(AprioriAlgo.getFrequentPatterns(transactions, minSupport));
			
			//not pattern classes in a new pattern
			Set<String> allTransClasses = new HashSet<String>();
			for (Set<String> tra:transactions){
					allTransClasses.addAll(tra);
			}
			for(Set<String> pattern:frequentPatterns){
				allTransClasses.removeAll(pattern);
			}
//			frequentPatterns.add(allTransClasses);
			totalNoPatterns = frequentPatterns.size();
			for(Set<String> frequentPattern : frequentPatterns)
			{
				totalPatternSize += frequentPattern.size();
			}
			
			//print transaction
			try {
				printTransactios(transactions, new PrintStream(new FileOutputStream(directory + "/ transactions.txt")));
				printFrequentPatterns(frequentPatterns, new PrintStream(new FileOutputStream(directory + "/ frequent patterns.txt")));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Identify components from each frequent pattern");
			//Identify components from each frequent pattern
			//1. get actual class object represent frequent patterns
			Set<Set<Clazz>> frequentPatternsAPI = new HashSet<Set<Clazz>>();
			for(Set<String> frequentPattern : frequentPatterns)
			{
				Set<Clazz> classes = new HashSet<Clazz>();
				for(String className : frequentPattern)
				{
					classes.add(oosystemAPI.getClazzByName(className));
				}
				frequentPatternsAPI.add(classes);
			}
			System.out.println("apply lexical, semantic and support as a function to identify components from each frequent pattern");
			//2. apply lexical, semantic and support as a function to identify components from each frequent pattern
			Set<Set<Clazz>> interfacesAPI = new HashSet<Set<Clazz>>();
			for(Set<Clazz> frequentPatternAPI : frequentPatternsAPI)
			{
				BinaryTree binaryTree = ClusteringUtils.clusteringAPI(frequentPatternAPI, transactions);
				Set<Set<Clazz>> clusters = ClusteringUtils.parcoursDendrogrammeAPI(binaryTree,0.5,transactions);
				interfacesAPI.addAll(clusters);
			}
			totalNoInterfaces = interfacesAPI.size();
			for(Set<Clazz> interAPI : interfacesAPI){
				totalInterfacesSize += interAPI.size();
			}
			
			try {
				printStatisticsPhase2(new PrintStream(new FileOutputStream(directory + "/" + " Statistics Phase2.txt")));
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			System.out.println("add most similar remaining api classes to initial api components");
			
			transactions = null;
			frequentPatterns = null;
			frequentPatternsAPI = null;
			System.gc();
			
			//3. add most similar remaining api classes to initial api components
			for(Set<Clazz> interfaceAPI : interfacesAPI)
			{
				Set<Clazz> pComp = ExtractPotentialComponent.extractPotenComp(oosystemAPI.getClazzes(), interfaceAPI);
				if(componentsAPI.add(pComp)){
					totalAPIComponantsSize += pComp.size();
				}
				
			}
			totalNoAPIComponants = componentsAPI.size();
			System.out.println("print API cluster");
			//4. print API cluster
			try {
				printFinalStatistics(new PrintStream(new FileOutputStream(directory + "/" + " Final Statistics.txt")));
				ClusteringUtils.printClusters(componentsAPI, new PrintStream(new FileOutputStream(directory + "/" +  "API clusters.txt")));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			


			//show dialog when simulation finished
			boolean response = MessageDialog.openConfirm(Display.getCurrent().getActiveShell(), "ROMANTIC", "The simulashon has finished \n Do you want to exit?");
			if(response){
				System.exit(0);
			}
			System.out.println("AndroidAPIHandler.execute() is finished");
}

public static void printTransactios(Set<Set<String>> transactions, PrintStream out) {
	int i = 0;
	for (Set<String> transaction: transactions) {
		out.println("T["+i+"] : ");
		for (String clazz: transaction) {
			out.print(clazz + "  ");
		}
		out.println();
		i++;
	}
}

public static void printFrequentPatterns(Set<Set<String>> frequentPatterns, PrintStream out) {
	int i = 0;
	for (Set<String> frequentPattern: frequentPatterns) {
		out.println("F.P["+i+"] : ");
		for (String clazz: frequentPattern) {
			out.print(clazz + "  ");
		}
		out.println();
		i++;
	}
}

public static void printStatisticsPhase1(PrintStream out) {
	out.println("Avg No Components = " + ((double)totalNoComponants / (double)totalNoProjects));
	out.println("Avg components size = " + ((double)totalNoClasses / (double)totalNoComponants));
	out.println("No of Clients = " + totalNoProjects);
	out.println("Avg Client Size = " + ((double)totalNoClasses / (double)totalNoProjects));
	out.println("Total No of Components = " + totalNoComponants);
	out.println("Avg Transaction Size = " + ((double)totalTransactionsSize / (double)totalNoTransactions));
	out.println("Avg  No Transaction = " + ((double)totalNoTransactions / (double)totalNoProjects));
	out.println("API Size = " + totalNoAPIClasses);
	out.println("Avg Components Used API % = " + ((double)totalNoTransactions / (double)totalNoComponants));
	
	}

public static void printStatisticsPhase2(PrintStream out) {
	out.println("Avg Patterns Size = " + ((double)totalPatternSize / (double)totalNoPatterns));
	out.println("Total No Patterns = " + totalNoPatterns);
	
	out.println("Total No of Interface = " + totalNoInterfaces);
	out.println("Avg Interface Size = " + ((double)totalInterfacesSize / (double)totalNoInterfaces));
	out.println("Avg Interface in pattern = " + ((double)totalNoInterfaces / (double)totalNoPatterns));
}

public static void printFinalStatistics(PrintStream out) {
	
	out.println("Total No of API Componants = " + totalNoAPIComponants);
	out.println("Avg API Components Size = " + ((double)totalAPIComponantsSize / (double)totalNoAPIComponants));
}

public static void printProjectsName(PrintStream out) {
	out.println(projectsNames);
}


}
