package romantic;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;

import romantic.clustering.BinaryTree;
import romantic.clustering.ClusteringUtils;
import romantic.geneticalgorithm.GeneticAlgorithmUtils;
import romantic.metamodel.Clazz;
import romantic.metamodel.OOSystem;
import romantic.parsing.Util;

public class HierarchicGenetic {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		OOSystem oosystem = new OOSystem();
		Collection<File> listFiles = FileUtils.listFiles(new File("projet"), new String[] {"java"}, true);
		for (File file : listFiles) {
			String path = new File("projet").toURI().relativize(file.toURI()).getPath();
			Util.parse(path, oosystem);
		}
		Util.printSystem(oosystem, new PrintStream(new FileOutputStream("system.txt")));
		BinaryTree binaryTree = ClusteringUtils.clustering(oosystem.getClazzes());
		//ClusteringUtils2.parcoursDendro(binaryTree, "  ");
		Set<Set<Clazz>> clusters = ClusteringUtils.parcoursDendrogramme(binaryTree,0.5);
		ClusteringUtils.printClusters(clusters, new PrintStream(new FileOutputStream("clusters.txt")));
		System.out.println("Qualité de la solution : " + GeneticAlgorithmUtils.fChromosomeComposant(clusters));
		System.out.println("Nombre de classes : " + oosystem.getClazzes().size());
		//Nombre de clusters
		System.out.println("Nombre de clusters : " + clusters.size());
		double moyenne = oosystem.getClazzes().size();
		moyenne /= clusters.size();
		System.out.println("Nombre moyen de classes par clusters : " + moyenne);
		//Nombre maximale de classes par clusters
		int max = 0;
		for (Set<Clazz> cluster : clusters) {
			if (cluster.size()>max) {
				max = cluster.size();
			}
		}
		System.out.println("Nombre maximal de classes par clusters : " + max);
		System.in.read();
		Set<Clazz> greatestCluster = null;
		int maxClazzPerCluster = 0;
		for (Set<Clazz> cluster : clusters) {
			if (cluster.size()>maxClazzPerCluster) {
				greatestCluster = cluster;
				maxClazzPerCluster = cluster.size();
			}
		}
		
		List<Set<Set<Clazz>>> population = new ArrayList<Set<Set<Clazz>>>();
		population.add(clusters);
		population.add(clusters);
		population.add(clusters);
		population.add(clusters);
		population.add(clusters);
		for (int i=1;i<=20;i++) {
			Set<Set<Clazz>> clustersMutation = new HashSet<Set<Clazz>>();
			for (Set<Clazz> cluster : clusters) {
				Set<Clazz> clusterClone = new HashSet<Clazz>(cluster);
				clustersMutation.add(clusterClone);
			}
			GeneticAlgorithmUtils.mutation(clustersMutation, 1.0);
			population.add(clustersMutation);
		}
		
		for (int i=0;i<25;i++) {
			population = GeneticAlgorithmUtils.selection1(population);
			GeneticAlgorithmUtils.croisement(population);
			GeneticAlgorithmUtils.mutationPopulation(population, 0.5);

			population = GeneticAlgorithmUtils.selection2(population, 25);
			System.out.println("***********");
			System.out.println("generation "+i);
			System.out.println("***********");
			
			
//			for (Set<Set<Clazz>> chromosome : population) {
//				System.out.println("chromosome " + chromosome + " f="+GeneticAlgorithmUtils.fChromosomeComposant(chromosome));
//							
//			}
			//System.in.read();
			if (population.isEmpty()) break;
			clusters = GeneticAlgorithmUtils.bestChromosome(population);
			System.out.println(GeneticAlgorithmUtils.fChromosomeComposant(clusters));
		}

		

		
		//Set<Set<Clazz>> clusters = GeneticAlgorithmUtils.bestChromosome(population);
		ClusteringUtils.printClusters(clusters, new PrintStream(new FileOutputStream("clusters.txt")));

		System.out.println("Qualité de la solution : " + GeneticAlgorithmUtils.fChromosomeComposant(clusters));
		System.out.println("Nombre de classes : " + oosystem.getClazzes().size());
		//Nombre de clusters
		System.out.println("Nombre de clusters : " + clusters.size());
		moyenne = oosystem.getClazzes().size();
		moyenne /= clusters.size();
		System.out.println("Nombre moyen de classes par clusters : " + moyenne);
		//Nombre maximale de classes par clusters
		max = 0;
		for (Set<Clazz> cluster : clusters) {
			if (cluster.size()>max) {
				max = cluster.size();
			}
		}
		System.out.println("Nombre maximal de classes par clusters : " + max);
	}


}
