package romantic.simulatedAnnealing;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import romantic.metamodel.Clazz;
import romantic.metrics.Metrics;

public class SimulatedAnnealingUtils {
	public static Set<Set<Clazz>> initialSolution(Set<Clazz> clazzes) {
		Random random = new Random();
		List<Set<Clazz>> chromosomeAsList = new ArrayList<Set<Clazz>>();
		//générer un chromosome aléatoirement
		int nombreDeGenes = random.nextInt(clazzes.size())/2 + 1;
		for (int j=0;j<nombreDeGenes;j++) {
			Set<Clazz> cluster = new HashSet<Clazz>();
			chromosomeAsList.add(cluster);
		}
		for (Clazz clazz : clazzes) {
			int k = random.nextInt(nombreDeGenes);
			chromosomeAsList.get(k).add(clazz);
		}
	
		Set<Set<Clazz>> genesToRemove = new HashSet<Set<Clazz>>();
		for (Set<Clazz> cluster : chromosomeAsList) {
			if (cluster.size()==0) {
				genesToRemove.add(cluster);
			}
		}
		chromosomeAsList.removeAll(genesToRemove);
		Set<Set<Clazz>> chromosome = new HashSet<Set<Clazz>>(chromosomeAsList);
		return chromosome;
	}
	
//	public static Set<Set<Clazz>> voisin(Set<Set<Clazz>> solution) {
//		Set<Set<Clazz>> chromosome = new HashSet<Set<Clazz>>();
//		for (Set<Clazz> cluster : solution) {
//			Set<Clazz> clusterToAdd = new HashSet<Clazz>();
//			for (Clazz clazz : cluster) {
//				clusterToAdd.add(clazz);
//			}
//			chromosome.add(clusterToAdd);
//		}
//		Random random = new Random();
//		double rFusion = random.nextDouble();
//		if (rFusion<1.0/2.0) {
//			List<Set<Clazz>> chromosomeAsList = new ArrayList<Set<Clazz>>(chromosome);
//			int index1 = random.nextInt(chromosomeAsList.size());
//			Set<Clazz> gene1 = chromosomeAsList.get(index1);
//			int index2 = index1;
//			while (index2==index1 && chromosomeAsList.size()!=1) {
//				index2 = random.nextInt(chromosomeAsList.size());
//			}
//			Set<Clazz> gene2 = chromosomeAsList.get(index2);
//			Set<Clazz> fusion = new HashSet<Clazz>(gene1);
//			fusion.addAll(gene2);
//			chromosome.remove(gene1);
//			chromosome.remove(gene2);
//			chromosome.add(fusion);
//		}
//		double rSeparation = random.nextDouble();
//		if (rSeparation<1.0/2.0) {
//			List<Set<Clazz>> chromosomeAsList = new ArrayList<Set<Clazz>>(chromosome);
//			int index = random.nextInt(chromosomeAsList.size());
//			Set<Clazz> geneToSeparate = chromosomeAsList.get(index);
//			List<Clazz> geneToSeparateAsList = new ArrayList<Clazz>(geneToSeparate);
//			int index2 = random.nextInt(geneToSeparate.size());
//			List<Clazz> gene1AsList = geneToSeparateAsList.subList(0, index2);
//			List<Clazz> gene2AsList = geneToSeparateAsList.subList(index2, geneToSeparate.size());
//			Set<Clazz> gene1 = new HashSet<Clazz>(gene1AsList);
//			Set<Clazz> gene2 = new HashSet<Clazz>(gene2AsList);
//			chromosome.remove(geneToSeparate);
//			if (gene1.size()>0)
//				chromosome.add(gene1);
//			if (gene2.size()>0)
//			chromosome.add(gene2);
//			
//		}
//		double rAdaptation = random.nextDouble();
//		if (rAdaptation<0/3) {
//			//adaptation
//		}
//		return chromosome;
//		
//	}
	
	public static Set<Set<Clazz>> voisin(Set<Set<Clazz>> solution) {
		Set<Set<Clazz>> chromosome = new HashSet<Set<Clazz>>();
		for (Set<Clazz> cluster : solution) {
			Set<Clazz> clusterToAdd = new HashSet<Clazz>();
			for (Clazz clazz : cluster) {
				clusterToAdd.add(clazz);
			}
			chromosome.add(clusterToAdd);
		}
		
		List<Set<Clazz>> chromosomeAsList = new ArrayList<Set<Clazz>>(chromosome);
		int index1 = 0;
		int index2 = 1;
		Set<Clazz> cluster = new HashSet<Clazz>();
		cluster.addAll(chromosomeAsList.get(0));
		cluster.addAll(chromosomeAsList.get(1));
		double fmax = Metrics.f(cluster);
		for (int i=0;i<chromosomeAsList.size();i++)
			for (int j=i+1;j<chromosomeAsList.size();j++) {
				Set<Clazz> currentCluster = new HashSet<Clazz>();
				currentCluster.addAll(chromosomeAsList.get(i));
				currentCluster.addAll(chromosomeAsList.get(j));
				if (Metrics.f(currentCluster)>fmax) {
					index1 = i;
					index2 = j;
					fmax = Metrics.f(currentCluster);
				}
			}
		Set<Clazz> gene1 = chromosomeAsList.get(index1);
		Set<Clazz> gene2 = chromosomeAsList.get(index2);
		Set<Clazz> fusion = new HashSet<Clazz>(gene1);
		fusion.addAll(gene2);
		chromosome.remove(gene1);
		chromosome.remove(gene2);
		chromosome.add(fusion);

		int index = 0;
		double fmaxmax = Metrics.f(chromosomeAsList.get(0));
		for (int i=1;i<chromosomeAsList.size();i++) {
			Set<Clazz> currentCluster = chromosomeAsList.get(i);
			if (Metrics.f(currentCluster)>fmaxmax) {
				fmaxmax = Metrics.f(currentCluster);
				index = i;
			}
		}
		
		Set<Clazz> geneToSeparate = chromosomeAsList.get(index);
		List<Clazz> geneToSeparateAsList = new ArrayList<Clazz>(geneToSeparate);
		Random random = new Random();
		int index22 = random.nextInt(geneToSeparate.size());
		List<Clazz> gene1AsList = geneToSeparateAsList.subList(0, index22);
		List<Clazz> gene2AsList = geneToSeparateAsList.subList(index22, geneToSeparate.size());
		Set<Clazz> gene12 = new HashSet<Clazz>(gene1AsList);
		Set<Clazz> gene22 = new HashSet<Clazz>(gene2AsList);
		chromosome.remove(geneToSeparate);
		if (gene12.size()>0)
			chromosome.add(gene1);
		if (gene22.size()>0)
		chromosome.add(gene2);
		
		double rAdaptation = random.nextDouble();
		if (rAdaptation<0/3) {
			//adaptation
		}
		return chromosome;
		
	}
	
	public static double fSolution(Set<Set<Clazz>> chromosome) {
		List<Set<Clazz>> chromosomeAsList = new ArrayList<Set<Clazz>>(chromosome);
		Collections.sort(chromosomeAsList, new Comparator<Set<Clazz>>() {
			@Override
			public int compare(Set<Clazz> cluster1, Set<Clazz> cluster2) {
				double f1 =  Metrics.f(cluster1);
				double f2 =  Metrics.f(cluster2);
				if (f1>f2)
					return 1;
				else if (f1==f2)
					return 0;
				else
					return -1;
					
			}
		});
		double mediane = Metrics.f(chromosomeAsList.get(chromosomeAsList.size()/2));
		double f = 0;
//		double f2 = 0;
//		double f3 = 0;
		int numberOfClasses = 0;
		for (Set<Clazz> cluster : chromosome) {
			f += Metrics.f(cluster);//*cluster.size();
//			numberOfClasses += cluster.size();
		}
//		for (Set<Clazz> cluster : chromosome) {
//			f2 += ((double)cluster.size())/((double)numberOfClasses);
//		}
		f /= chromosome.size();//numberOfClasses;
//		f2 /= chromosome.size();
//		if (f2>=0 && f2<=0.5) {
//			f2 = 2 * f2;
//		} else {
//			f2 = 2 * (1 - f2);
//		}
//		f3 = (double)chromosome.size()/(double)numberOfClasses;
//		if (f3>=0 && f3<=0.5) {
//			f3 = 2*f3;
//		} else {
//			f3 = 2*(1-f3);
//		}
//		int coef1 = 40;
//		int coef2 = 20;
//		int coef3 = 0;
		
//		return (coef1*f + coef2*f2 + coef3*f3) / (coef1 + coef2 + coef3);
//		return (mediane + f) / 2;
//		return f;
		double nbr = 0;
		for (Set<Clazz> cluster : chromosome) {
			if (Metrics.f(cluster)>0.65) {
				nbr++;
			}
		}
		nbr /= chromosome.size();
		return nbr;
		//return (Math.min(mediane, f));
	}
	
	public static double fSolutionAverage(Set<Set<Clazz>> chromosome) {
		List<Set<Clazz>> chromosomeAsList = new ArrayList<Set<Clazz>>(chromosome);
		Collections.sort(chromosomeAsList, new Comparator<Set<Clazz>>() {
			@Override
			public int compare(Set<Clazz> cluster1, Set<Clazz> cluster2) {
				double f1 =  Metrics.f(cluster1);
				double f2 =  Metrics.f(cluster2);
				if (f1>f2)
					return 1;
				else if (f1==f2)
					return 0;
				else
					return -1;
					
			}
		});
		double mediane = Metrics.f(chromosomeAsList.get(chromosomeAsList.size()/2));
		double f = 0;
//		double f2 = 0;
//		double f3 = 0;
		int numberOfClasses = 0;
		for (Set<Clazz> cluster : chromosome) {
			f += Metrics.f(cluster)*cluster.size();
			numberOfClasses += cluster.size();
		}
//		for (Set<Clazz> cluster : chromosome) {
//			f2 += ((double)cluster.size())/((double)numberOfClasses);
//		}
		f /= numberOfClasses;
//		f2 /= chromosome.size();
//		if (f2>=0 && f2<=0.5) {
//			f2 = 2 * f2;
//		} else {
//			f2 = 2 * (1 - f2);
//		}
//		f3 = (double)chromosome.size()/(double)numberOfClasses;
//		if (f3>=0 && f3<=0.5) {
//			f3 = 2*f3;
//		} else {
//			f3 = 2*(1-f3);
//		}
//		int coef1 = 40;
//		int coef2 = 20;
//		int coef3 = 0;
		
//		return (coef1*f + coef2*f2 + coef3*f3) / (coef1 + coef2 + coef3);
//		return (mediane + f) / 2;
		return f;
//		double nbr = 0;
//		for (Set<Clazz> cluster : chromosome) {
//			if (Metrics.f(cluster)>0.65) {
//				nbr++;
//			}
//		}
//		nbr /= chromosome.size();
//		return nbr;
		//return (Math.min(mediane, f));
	}
	
}

