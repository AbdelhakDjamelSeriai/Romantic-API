package romantic;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Collection;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.apache.commons.io.FileUtils;

import romantic.clustering.ClusteringUtils;
import romantic.geneticalgorithm.GeneticAlgorithmUtils;
import romantic.metamodel.Clazz;
import romantic.metamodel.OOSystem;
import romantic.parsing.Util;
import romantic.simulatedAnnealing.SimulatedAnnealingUtils;

public class GeneticAnnealing {
	public static void main(String[] args) throws IOException {
		OOSystem oosystem = new OOSystem();
		Collection<File> listFiles = FileUtils.listFiles(new File("projet"), new String[] {"java"}, true);
		for (File file : listFiles) {
			String path = new File("projet").toURI().relativize(file.toURI()).getPath();
			Util.parse(path, oosystem);
		}
		Util.printSystem(oosystem, new PrintStream(new FileOutputStream("system.txt")));
		Set<Set<Clazz>> clusters = null;
		List<Set<Set<Clazz>>> population = GeneticAlgorithmUtils.initialPopulation(oosystem.getClazzes(), 25);
		for (int i=0;i<25;i++) {
			System.out.println("***********");
			System.out.println("generation "+i);
			System.out.println("***********");
			
			
			//for (Set<Set<Clazz>> chromosome : population) {
			//	System.out.println("chromosome " + chromosome + " f="+GeneticAlgorithmUtils.fChromosomeComposant(chromosome));
							
			//}
			population = GeneticAlgorithmUtils.selection1(population);
			GeneticAlgorithmUtils.croisement(population);
			GeneticAlgorithmUtils.mutationPopulation(population, 0.5);
			population = GeneticAlgorithmUtils.selection2(population, 25);

			//System.in.read();
			if (population.isEmpty()) break;
			clusters = GeneticAlgorithmUtils.bestChromosome(population);
			System.out.println(GeneticAlgorithmUtils.fChromosomeComposant(clusters));
		}

		

		
		//Set<Set<Clazz>> clusters = GeneticAlgorithmUtils.bestChromosome(population);
		ClusteringUtils.printClusters(clusters, new PrintStream(new FileOutputStream("clusters.txt")));

		System.out.println("Qualité de la solution : " + GeneticAlgorithmUtils.fChromosomeComposant(clusters));
		System.out.println("Qualité moyenne de la solution : " + SimulatedAnnealingUtils.fSolutionAverage(clusters));

		
		System.out.println("Nombre de classes : " + oosystem.getClazzes().size());
		//Nombre de clusters
		System.out.println("Nombre de clusters : " + clusters.size());
		double moyenne = oosystem.getClazzes().size();
		moyenne /= clusters.size();
		System.out.println("Nombre moyen de classes par clusters : " + moyenne);
		//Nombre maximale de classes par clusters
		int max = 0;
		for (Set<Clazz> cluster : clusters) {
			if (cluster.size()>max) {
				max = cluster.size();
			}
		}
		System.out.println("Nombre maximal de classes par clusters : " + max);
		
		System.in.read();
		
		Set<Set<Clazz>> solution = clusters;
		double f = SimulatedAnnealingUtils.fSolution(solution);
		double fBest = f;
		Set<Set<Clazz>> solutionBest = solution;
		int k = 0;
		int kmax = 60;
		double t = 100;
		double lambda = 0.98;
		Random random = new Random();
		while (t>0.09) {
			Set<Set<Clazz>> voisin = SimulatedAnnealingUtils.voisin(solution);
			double fVoisin = SimulatedAnnealingUtils.fSolution(voisin);
			double diff = fVoisin - f;
			if (fVoisin>fBest) {
				solutionBest = voisin;
				fBest = fVoisin;
			}
			if (fVoisin>f || random.nextDouble() > Math.exp(-(Math.abs(diff))/t)) {
				solution = voisin;
				f = fVoisin;
			}
			t *= lambda;
			k = k + 1;
			System.out.print("f="+SimulatedAnnealingUtils.fSolution(solution));
			System.out.print(" Math.exp(-(Math.abs(diff))/t)=" + Math.exp(-(Math.abs(diff))/t));
			System.out.print(" T = " + t);
			System.out.println(" diff = " + (diff));
			//System.in.read();
		}
		
		ClusteringUtils.printClusters(solutionBest, new PrintStream(new FileOutputStream("clusters.txt")));

		System.out.println("Qualité de la solution : " + GeneticAlgorithmUtils.fChromosomeComposant(solutionBest));
		System.out.println("Qualité moyenne de la solution : " + SimulatedAnnealingUtils.fSolutionAverage(clusters));

		System.out.println("Nombre de classes : " + oosystem.getClazzes().size());
		//Nombre de clusters
		System.out.println("Nombre de clusters : " + solutionBest.size());
		moyenne = oosystem.getClazzes().size();
		moyenne /= solutionBest.size();
		System.out.println("Nombre moyen de classes par clusters : " + moyenne);
		//Nombre maximale de classes par clusters
		max = 0;
		for (Set<Clazz> cluster : solutionBest) {
			if (cluster.size()>max) {
				max = cluster.size();
			}
		}
		System.out.println("Nombre maximal de classes par clusters : " + max);
	}
}
