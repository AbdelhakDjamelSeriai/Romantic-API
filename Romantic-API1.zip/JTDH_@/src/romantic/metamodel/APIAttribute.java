package romantic.metamodel;

public class APIAttribute extends Member {

	public APIAttribute(String name, Clazz clazz) {
		super(name, clazz);
	}

}
