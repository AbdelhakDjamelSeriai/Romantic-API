package romantic.metamodel;

import java.util.HashSet;
import java.util.Set;

public class APIMethod extends Member {

	private Set<APIMethod> calledMethods = new HashSet<APIMethod>();
	private Set<Attribute> accessedAttributes = new HashSet<Attribute>();
	private boolean isPublic = false;
	private boolean isCalled = false; // to break recursion function
	private boolean isAllAccessedAttributes = false;

	public APIMethod(String name, Clazz clazz) {
		super(name, clazz);
	}

	public void addCalledMethod(APIMethod m) {
		calledMethods.add(m);
	}

	public void addAccessedAttribute(Attribute a) {
		accessedAttributes.add(a);
	}

	public Set<APIMethod> getCalledMethods() {
		return calledMethods;
	}

	public Set<Attribute> getAccessedAttributes() {
		
		if (!isAllAccessedAttributes) { //just do it at first time
			for (APIMethod method : calledMethods) {
				//zak to do : check the secound condition
				if (isCalled || method.getClazz().getName() != getClazz().getName()) {// break recursion function
					break;
				}
				isCalled = true;
				accessedAttributes.addAll(method.getAccessedAttributes());
			}
		}
		isAllAccessedAttributes = true;
		isCalled = false;
		return accessedAttributes;
	}

	public void setPublicFlag(boolean isPublic) {
		this.isPublic = isPublic;
	}

	public boolean isPublic() {
		return isPublic;
	}

}
