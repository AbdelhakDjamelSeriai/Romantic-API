package romantic.metamodel;

import java.util.HashSet;
import java.util.Set;

public class Method extends Member {

	private Set<Method> calledMethods = new HashSet<Method>();
	private Set<APIMethod> calledAPIMethods = new HashSet<APIMethod>();
	private Set<Attribute> accessedAttributes = new HashSet<Attribute>();
	private Set<APIAttribute> apiAccessedAttributes = new HashSet<APIAttribute>();
	private boolean isPublic = false;
	private boolean isCalled = false; // to break recursion function
	private boolean isAllAccessedAttributes = false;

	public Method(String name, Clazz clazz) {
		super(name, clazz);
	}

	public void addCalledMethod(Method m) {
		calledMethods.add(m);
	}
	
	public void addCalledAPIMethod(APIMethod m) {
		calledAPIMethods.add(m);
	}

	public void addAccessedAttribute(Attribute a) {
		accessedAttributes.add(a);
	}
	
	public void addAPIAccessedAttribute(APIAttribute a) {
		apiAccessedAttributes.add(a);
	}

	public Set<Method> getCalledMethods() {
		return calledMethods;
	}
	
	public Set<APIMethod> getAPICalledMethods() {
		return calledAPIMethods;
	}

	public Set<Attribute> getAccessedAttributes(Set<Clazz> clazzes) {
		
		if (!isAllAccessedAttributes) { //just do it at first time
			for (Method method : calledMethods) {
				//zak to do : check the secound condition
				if (isCalled || !clazzes.contains(method.getClazz())) {// break recursion function
					break;
				}
				isCalled = true;
				accessedAttributes.addAll(method.getAccessedAttributes(clazzes));
			}
		}
		isAllAccessedAttributes = true;
		isCalled = false;
		return accessedAttributes;
	}
	
	public Set<APIAttribute> getAPIAccessedAttributes() {
		return apiAccessedAttributes;
	}

	public void setPublicFlag(boolean isPublic) {
		this.isPublic = isPublic;
	}

	public boolean isPublic() {
		return isPublic;
	}

}
