package romantic.metamodel;

public class Attribute extends Member {

	public Attribute(String name, Clazz clazz) {
		super(name, clazz);
	}

}
