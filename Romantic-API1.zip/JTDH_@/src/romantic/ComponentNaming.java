package romantic;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import romantic.metamodel.Clazz;


public class ComponentNaming {
	public static String componentName(Set<Clazz> cluster) {
		Map<String,Double> wordsWeight = new HashMap<String,Double>();
		for (Clazz c : cluster) {
			String[] parts = c.getName().split("(?<!(^|[A-Z]))(?=[A-Z])|(?<!^)(?=[A-Z][a-z])");
			Double weight = wordsWeight.get(parts[0]);
			if (weight==null) {
				wordsWeight.put(parts[0], 1.0);
			} else {
				wordsWeight.put(parts[0], weight+1.0);
			}
			
			for (int i=1;i<parts.length;i++) {
				Double secondWordWeight = wordsWeight.get(parts[i]);
				if (secondWordWeight==null) {
					wordsWeight.put(parts[i], 0.5);
				} else {
					wordsWeight.put(parts[i],secondWordWeight+0.5);
				}
			}
		}
		SortedSet<Entry<String, Double>> entriesSortedByValues = entriesSortedByValues(wordsWeight);
		Iterator<Entry<String, Double>> iterator = entriesSortedByValues.iterator();
		String result = "";
		if (iterator.hasNext()) { 
			String key = iterator.next().getKey();
			result = key;
		}
		if (iterator.hasNext()) { 
			String key = iterator.next().getKey();
			result = result + key;
		}
		if (iterator.hasNext()) { 
			String key = iterator.next().getKey();
			result = result + key;
		}
		return result;
		
	}
	
	static <K,V extends Comparable<? super V>> SortedSet<Map.Entry<K,V>> entriesSortedByValues(Map<K,V> map) {
        SortedSet<Map.Entry<K,V>> sortedEntries = new TreeSet<Map.Entry<K,V>>(
            new Comparator<Map.Entry<K,V>>() {
                @Override public int compare(Map.Entry<K,V> e1, Map.Entry<K,V> e2) {
                    int res = e2.getValue().compareTo(e1.getValue());
                    return res != 0 ? res : 1; // Special fix to preserve items with equal values
                }
            }
        );
        sortedEntries.addAll(map.entrySet());
        return sortedEntries;
    }


	
}
