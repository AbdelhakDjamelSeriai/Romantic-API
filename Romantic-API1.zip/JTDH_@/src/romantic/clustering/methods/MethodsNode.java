package romantic.clustering.methods;

import java.util.Set;

import romantic.metamodel.Method;


public abstract class MethodsNode {
	public abstract Set<Method> getMethods();
}
