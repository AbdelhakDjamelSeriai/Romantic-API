package romantic.clustering.methods;

import java.util.HashSet;
import java.util.Set;

import romantic.metamodel.Method;


public class MethodsBinaryTree extends MethodsNode{
	private MethodsNode node1;
	private MethodsNode node2;
	
	
	
	public MethodsBinaryTree() {
		super();
	}

	public MethodsNode getMethodsNode1() {
		return node1;
	}
	public void setMethodsNode1(MethodsNode node1) {
		this.node1 = node1;
	}
	public MethodsNode getMethodsNode2() {
		return node2;
	}
	public void setMethodsNode2(MethodsNode node2) {
		this.node2 = node2;
	}
	
	public int numberOfLeaves() {
		if (node1 instanceof MethodsLeaf) {
			if (node2 instanceof MethodsLeaf) {
				return 2;
			} else {
				return 1 + ((MethodsBinaryTree)node2).numberOfLeaves();
			}
		} else {
			if (node2 instanceof MethodsLeaf) {
				return ((MethodsBinaryTree)node1).numberOfLeaves() + 1;
			} else {
				return ((MethodsBinaryTree)node1).numberOfLeaves() + ((MethodsBinaryTree)node2).numberOfLeaves();
			}
		}
		
	}
	@Override
	public Set<Method> getMethods() {
		Set<Method> methods = new HashSet<Method>();
		methods.addAll(node1.getMethods());
		methods.addAll(node2.getMethods());
		return methods;
	}
	
}
