package romantic.clustering.methods;

import java.io.PrintStream;
import java.util.HashSet;
import java.util.Set;
import java.util.Stack;


import romantic.metamodel.Clazz;
import romantic.metamodel.Method;
import romantic.metrics.Metrics;

public class MethodsClusteringUtils {
	public static MethodsBinaryTree clustering(Set<Method> methods,Set<Set<Clazz>> clusters) {
		Set<MethodsNode> noeuds = new HashSet<MethodsNode>();
		int taille = methods.size();
		double max;
		MethodsBinaryTree b = null;
		for (Method c : methods) {
			noeuds.add(new MethodsLeaf(c));
		}
		for (MethodsNode n : noeuds) {
			Set<Method> cluster = new HashSet<Method>();
			cluster.addAll(n.getMethods());
			max = Metrics.fInterfaces(cluster,clusters);
			System.out.println(cluster + " " + max);
		}
		do {
			MethodsNode[] noeudsArray = noeuds.toArray(new MethodsNode[0]);
			int nombre = 1;
			int total = noeuds.size() * (noeuds.size() - 1) / 2;
			MethodsNode n1 = noeudsArray[0];
			MethodsNode n2 = noeudsArray[1];
			Set<Method> cluster = new HashSet<Method>();
			cluster.addAll(n1.getMethods());
			cluster.addAll(n2.getMethods());
			max = Metrics.fInterfaces(cluster,clusters);
			//System.out.println(cluster + " " + max);
			System.out.println( nombre + "/" + total);
			nombre ++;
			for (int i=2;i<noeudsArray.length;i++) {
				Set<Method> cluster1 = new HashSet<Method>();
				cluster1.addAll(noeudsArray[0].getMethods());
				cluster1.addAll(noeudsArray[i].getMethods());

				double value = Metrics.fInterfaces(cluster1,clusters);
				//System.out.println(cluster1 + " " + value);
				System.out.println(nombre + "/" + total);
				nombre ++;
				if (value>max) {
					n1 = noeudsArray[0];
					n2 = noeudsArray[i];
					max = value;
				}
			}
			//System.out.println(max);
			for (int i=1;i<noeudsArray.length;i++) {
				for (int j=i+1;j<noeudsArray.length;j++) {
					Set<Method> cluster1 = new HashSet<Method>();
					cluster1.addAll(noeudsArray[i].getMethods());
					cluster1.addAll(noeudsArray[j].getMethods());

					double value = Metrics.fInterfaces(cluster1,clusters);
					//System.out.println(cluster1 + " " + value);
					System.out.println(nombre + "/" + total);
					nombre ++;
					if (value>=max) {
						n1 = noeudsArray[i];
						n2 = noeudsArray[j];
						max = value;
					}
				}
 			}
			b = new MethodsBinaryTree();
			b.setMethodsNode1(n1);
			b.setMethodsNode2(n2);
			System.out.println(b.numberOfLeaves());
			System.out.println(b.getMethods());
			noeuds.remove(n1);
			noeuds.remove(n2);
			noeuds.add(b);
			
		} while (b.numberOfLeaves()!=taille);
		return b;
	}
//	
	public static Set<Set<Method>> parcoursDendrogramme(MethodsBinaryTree dendrogramme, double t,Set<Set<Clazz>> clusters) {
		Set<Set<Method>> result = new HashSet<Set<Method>>();
		Stack<MethodsNode> pile = new Stack<MethodsNode>();
		pile.push(dendrogramme);
		while (!pile.isEmpty()) {
			MethodsNode pere = pile.pop();
			Set<Method> pereCluster = pere.getMethods();
			if (pere instanceof MethodsBinaryTree) {
				Set<Method> fils1Cluster = (((MethodsBinaryTree) pere).getMethodsNode1().getMethods());
				Set<Method> fils2Cluster = (((MethodsBinaryTree) pere).getMethodsNode2().getMethods());
				double valuePere = Metrics.fInterfaces(pereCluster,clusters);
				System.out.println("pere : " + valuePere);
				for (Method c : pereCluster) {
					System.out.println(c);
				}
				
				double valueFils1 = Metrics.fInterfaces(fils1Cluster,clusters);
				
				System.out.println("fils1 : " + valueFils1);
				for (Method c : fils1Cluster) {
					System.out.println(c);
				}
				
				double valueFils2 = Metrics.fInterfaces(fils2Cluster,clusters);
				
				System.out.println("fils2 : " + valueFils2);
				for (Method c : fils2Cluster) {
					System.out.println(c);
				}
				if (valuePere > (valueFils1 + valueFils2)*t)
					
//					if (valuePere > valueFils1 && valuePere > valueFils2)
						 {
					result.add(pereCluster);
				} else {
					pile.add(((MethodsBinaryTree) pere).getMethodsNode1());
					pile.add(((MethodsBinaryTree) pere).getMethodsNode2());
				}
					
//					if (valueFils1 > valuePere)
//					 {
//						pile.add(((MethodsBinaryTree) pere).getMethodsNode1());
//			} else if (valueFils2 > valuePere) {
//				pile.add(((MethodsBinaryTree) pere).getMethodsNode2());
//			} else {
//				result.add(pereComponentShape);
//			}
					
			} else {
				result.add(pereCluster);
			}
		}
		return result;
		
		
	}
	
	public static void parcoursDendro(MethodsBinaryTree dendro, String s) {
		System.out.println(s+ "pere" + dendro.getMethods());
		if (dendro.getMethodsNode1() instanceof MethodsBinaryTree)
		parcoursDendro((MethodsBinaryTree)dendro.getMethodsNode1(),s+"  ");
		else
			System.out.println(s + "  fils1" + ((MethodsLeaf)dendro.getMethodsNode1()).getMethods());
		if (dendro.getMethodsNode2() instanceof MethodsBinaryTree)
		parcoursDendro((MethodsBinaryTree)dendro.getMethodsNode2(),s+"  ");
		else
			System.out.println(s + "  fils2" + ((MethodsLeaf)dendro.getMethodsNode2()).getMethods());
	}
	
	
//	public static ComponentShape createComponentShapeFrommethods(Set<Class> methods) {
//		ConfigurationShape configurationShape = new ConfigurationShape();
//		ComponentShape componentShape = new ComponentShape();
//		componentShape.getMethods().addAll(methods);
//		componentShape.setConfigurationShape(configurationShape);
//		configurationShape.getComponentShapes().add(componentShape);
//		return componentShape;
//	}
//	
//	public static Set<ComponentShape> clusteringBasic(List<Class> methods, double t) {
//		Set<ComponentShape> partition = new HashSet<ComponentShape>();
//		while (!methods.isEmpty()) {
//			Class ci = methods.get(0);
//			ComponentShape c = new ComponentShape();
//			c.getMethods().add(ci);
//			methods.remove(ci);
//			List<Class> methodsClone = new ArrayList<Class>();
//			for (Class cj : methods) {
//				methodsClone.add(cj);
//			}
//			for (Class cj : methodsClone) {
//				System.out.println(ci + "," + cj + ":" +ObjectiveFunctionUtils.objFunction(ci, cj));
//				if (ObjectiveFunctionUtils.objFunction(ci, cj)>=t) {
//					c.getMethods().add(cj);
//					methods.remove(cj);
//				}
//			}
//			partition.add(c);
//			System.err.println("methods restantes : " + methods.size());
//		}
//		return partition;
//	}
	
	public static void printClusters(Set<Set<Method>> clusters,Set<Set<Clazz>> clazzesClusters, PrintStream out) {
		int i = 1;
		for (Set<Method> cluster: clusters) {
			out.print("Cluster " + i + "(" + cluster.size()+" method)");
//			out.println("cohesion : " + Metrics.tccMethods(cluster) +", sameInterface : " + Metrics.sameClassProportion(cluster) + ", invokationTogether : " + Metrics.invokedTogetherSameComponent(cluster, clazzesClusters));
			for (Method method: cluster) {
				out.println("  " + method.getClazz().getName()+"."+ method.getName());
			}
			i++;
		}
	}

}
