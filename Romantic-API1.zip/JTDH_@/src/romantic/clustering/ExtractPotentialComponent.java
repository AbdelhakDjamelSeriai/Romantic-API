
package romantic.clustering;

import java.util.HashSet;
import java.util.Set;

import romantic.metamodel.Clazz;
import romantic.metrics.Metrics;

/**
 * @author Anas Shatnawi
 * anasshatnawi@gmail.com
 */
public class ExtractPotentialComponent {
	
	//input: all classes, constrant classes
	//output: a potential component
	public static Set<Clazz> extractPotenComp(Set<Clazz> classes,
			Set<Clazz> constraint) {
		classes.removeAll(constraint);// remove the constriant classes form all classes
		Set<Clazz> addResult = new HashSet<Clazz>();// for the constrant classes
		Set<Clazz> bestResult = new HashSet<Clazz>();// holds the final component
		addResult.addAll(constraint); // add constraint classes
		bestResult.addAll(constraint); // initial best component
		double maxFF = -1;// initial the max quality as -1
		Clazz nearestClass = null; // holds the nearest class to the current component
		int count =0; // number of classes
		while (!classes.isEmpty()) { // to check all classes
			maxFF = -1; // reset the max quality every iteration
			nearestClass = null; // reset nearest class
			int i=0;// number of passed classes
			for (Clazz c : classes) {// travel through all classes
				Set<Clazz> tempCluster = new HashSet<Clazz>();// holds a candidate component 
				tempCluster.addAll(addResult);// add current component
				tempCluster.add(c); // add a class
				double fitness = Metrics.fAPI(tempCluster); // check the quality of current component + new class
				if (fitness>= maxFF) {
					maxFF =fitness;// update the quality
					nearestClass = c; // update the nearest class
				}
				i++; // increment number of passed classes
				// to break after checking 500  classes if you want
//				if (i >= 100){
//					break;
//				}
			}
			addResult.add(nearestClass); // add the nearest class to the current component
			if (maxFF > Metrics.fAPI(bestResult)) { // compare the best component quality with the new component
				bestResult = new HashSet<Clazz>(); // reset the best component
				bestResult.addAll(addResult);// new best component
			}
			classes.remove(nearestClass);// remove the nerest class from all classes
			count++;// increment number of checked classes
			//to break after 50 checking 50 classes if you want
			if (count >= 100){
				break;
			}
		}
		return bestResult;// return the potential component
	}

}
