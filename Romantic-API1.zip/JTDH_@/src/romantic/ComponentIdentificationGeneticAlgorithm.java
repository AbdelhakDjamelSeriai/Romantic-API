package romantic;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;

import romantic.clustering.ClusteringUtils;
import romantic.geneticalgorithm.GeneticAlgorithmUtils;
import romantic.metamodel.Clazz;
import romantic.metamodel.OOSystem;
import romantic.parsing.Util;
import romantic.simulatedAnnealing.SimulatedAnnealingUtils;

public class ComponentIdentificationGeneticAlgorithm {

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		OOSystem oosystem = new OOSystem();
		Collection<File> listFiles = FileUtils.listFiles(new File("projet"),
				new String[] { "java" }, true);
		for (File file : listFiles) {
			String path = new File("projet").toURI().relativize(file.toURI())
					.getPath();
			Util.parse(path, oosystem);
		}
		Util.printSystem(oosystem, new PrintStream(new FileOutputStream(
				"system.txt")));
		Set<Set<Clazz>> clusters = null;
		List<Set<Set<Clazz>>> population = GeneticAlgorithmUtils
				.initialPopulation(oosystem.getClazzes(), 25);
		for (int i = 0; i < 25; i++) {
			System.out.println("***********");
			System.out.println("generation " + i);
			System.out.println("***********");

			// for (Set<Set<Clazz>> chromosome : population) {
			// System.out.println("chromosome " + chromosome +
			// " f="+GeneticAlgorithmUtils.fChromosomeComposant(chromosome));

			// }
			population = GeneticAlgorithmUtils.selection1(population);
			GeneticAlgorithmUtils.croisement(population);
			GeneticAlgorithmUtils.mutationPopulation(population, 0.5);
			population = GeneticAlgorithmUtils.selection2(population, 25);

			// System.in.read();
			if (population.isEmpty())
				break;
			clusters = GeneticAlgorithmUtils.bestChromosome(population);
			System.out.println(GeneticAlgorithmUtils
					.fChromosomeComposant(clusters));
		}

		// Set<Set<Clazz>> clusters =
		// GeneticAlgorithmUtils.bestChromosome(population);
		ClusteringUtils.printClusters(clusters, new PrintStream(
				new FileOutputStream("clusters.txt")));

		System.out.println("Qualité de la solution : "
				+ GeneticAlgorithmUtils.fChromosomeComposant(clusters));
		System.out.println("Qualité moyenne de la solution : "
				+ SimulatedAnnealingUtils.fSolutionAverage(clusters));

		System.out.println("Nombre de classes : "
				+ oosystem.getClazzes().size());
		// Nombre de clusters
		System.out.println("Nombre de clusters : " + clusters.size());
		double moyenne = oosystem.getClazzes().size();
		moyenne /= clusters.size();
		System.out.println("Nombre moyen de classes par clusters : " + moyenne);
		// Nombre maximale de classes par clusters
		int max = 0;
		for (Set<Clazz> cluster : clusters) {
			if (cluster.size() > max) {
				max = cluster.size();
			}
		}
		System.out.println("Nombre maximal de classes par clusters : " + max);
	}

}
