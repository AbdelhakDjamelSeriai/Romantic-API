package romantic;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Collection;
import java.util.Set;


import org.apache.commons.io.FileUtils;

import romantic.clustering.BinaryTree;
import romantic.clustering.ClusteringUtils;
import romantic.metamodel.Clazz;
import romantic.metamodel.OOSystem;
import romantic.parsing.Util;


public class ComponentsIdentificationMain {
	public static void main(String pathname) throws IOException {
		OOSystem oosystem = new OOSystem();
		Collection<File> listFiles = FileUtils.listFiles(new File(pathname), new String[] {"java"}, true);
		//zax hint : loop for all java files
		for (File f : listFiles) {
			String path = f.toURI().getPath();
			Util.parse(path, oosystem);
		}
		Util.printSystem(oosystem, new PrintStream(new FileOutputStream("D:/Study/system.txt")));
		BinaryTree binaryTree = ClusteringUtils.clustering(oosystem.getClazzes());
		//ClusteringUtils2.parcoursDendro(binaryTree, "  ");
		Set<Set<Clazz>> clusters = ClusteringUtils.parcoursDendrogramme(binaryTree,0.5);
		ClusteringUtils.printClusters(clusters, new PrintStream(new FileOutputStream("D:/Study/clusters.txt")));
		
		System.out.println("Nombre de classes : " + oosystem.getClazzes().size());
		//Nombre de clusters
		System.out.println("Nombre de clusters : " + clusters.size());
		double moyenne = oosystem.getClazzes().size();
		moyenne /= clusters.size();
		System.out.println("Nombre moyen de classes par clusters : " + moyenne);
		//Nombre maximale de classes par clusters
		int max = 0;
		for (Set<Clazz> cluster : clusters) {
			if (cluster.size()>max) {
				max = cluster.size();
			}
		}
		System.out.println("Nombre maximal de classes par clusters : " + max);

	}
}
