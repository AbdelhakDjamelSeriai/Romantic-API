package dataMining.pattern;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class AprioriAlgo {

	public static int totNoOfClasses = 0;
	public static int totNoOfTrans= 0;

	public static Set<Set<String>> getFrequentPatterns(Set<Set<String>> transactions, double minSupport) {
		totNoOfTrans=transactions.size();
		
		Set<String> allClasses = new HashSet<String>();
		for(Set<String> tr:transactions){
			allClasses.addAll(tr);
		}
		totNoOfClasses=allClasses.size();
		System.err.println("number of classes in tranactions: "+totNoOfClasses);
		Set<Set<String>> frequentPatterns = new HashSet<Set<String>>();

		frequentPatterns = generateIndividualItem(transactions);
		removeItemsLessSupp(transactions, frequentPatterns, minSupport);
		
		int k = 1;
		Set<Set<String>> candidateSets = new HashSet<Set<String>>();
		candidateSets.addAll(frequentPatterns);
		do {
			k++;
			System.err.println("K= " + k);
			System.err.println("No of current candidate : " + candidateSets.size());
			Set<Set<String>> tempCandidateSets = new HashSet<Set<String>>();
			tempCandidateSets.addAll(candidateSets);
			candidateSets= new HashSet<Set<String>>();
			candidateSets = generateCandidatesSets(tempCandidateSets, k);
			removeItemsLessSupp(transactions, candidateSets, minSupport);
			frequentPatterns.addAll(candidateSets);
			if (candidateSets.size() == 1) {
				break;
			}
		} while ((k < totNoOfClasses) && (candidateSets.size() > 1));

		printFrequentItems(frequentPatterns);
		removeSubpatterns(frequentPatterns);
		printFrequentItems(frequentPatterns);
		
		return frequentPatterns;
	}

	public static void removeSubpatterns(Set<Set<String>> frequentPatterns) {
		ArrayList<Set<String>> set1 = new ArrayList<Set<String>>(frequentPatterns);
		ArrayList<Set<String>> set2 = new ArrayList<Set<String>>(frequentPatterns);
		Set<Set<String>> r = new HashSet<Set<String>>();
		for (int i = 0; i < set1.size(); i++) {
			for (int j = 0; j < set2.size(); j++) {
				if (set1.get(i) == set2.get(j)) {
					continue;
				}
				if (set1.get(i).containsAll(set2.get(j))) {
					r.add(set2.get(j));
				}
			}
		}
		frequentPatterns.removeAll(r);
	}

	public static Set<Set<String>> generateCandidatesSets(
			Set<Set<String>> oldCandidate, int k) {
		ArrayList<Set<String>> set1 = new ArrayList<Set<String>>(oldCandidate);
		ArrayList<Set<String>> set2 = new ArrayList<Set<String>>(oldCandidate);
		Set<Set<String>> results = new HashSet<Set<String>>();

		if (k == 2) {
			for (int i = 0; i < set1.size(); i++) {
				for (int j = 0; j < set2.size(); j++) {
					if (set1.get(i) == set2.get(j)) {
						continue;
					}
					Set<String> r = new HashSet<String>();
					r.addAll(set1.get(i));
					r.addAll(set2.get(j));
					results.add(r);
				}
			}
		} else {
			for (int i = 0; i < set1.size(); i++) {
				for (int j = 0; j < set2.size(); j++) {
					if (set1.get(i) == set2.get(j)) {
						continue;
					}
					Set<String> r = new HashSet<String>();
					r.addAll(set1.get(i));
					r.addAll(set2.get(j));
					if (r.size() == k) {
						results.add(r);
					}
				}
			}
		}
		return results;
	}

	public static void printFrequentItems(Set<Set<String>> items) {
		for (Set<String> str : items) {
			//to do print
		}
	}

	public static void removeItemsLessSupp(Set<Set<String>> transactions, Set<Set<String>> frequentPatterns, double minSupport) {
		Set<Set<String>> resuts = new HashSet<Set<String>>();
		for (Set<String> str : frequentPatterns) {
			if (getItemSupport(transactions, frequentPatterns, str) < minSupport) {
				resuts.add(str);
			}
		}
		frequentPatterns.removeAll(resuts);
	}

	public static double getItemSupport(Set<Set<String>> transactions, Set<Set<String>> frequentPatterns, Set<String> item) {
		int supp = 0;
		ArrayList<Set<String>> t = new ArrayList<Set<String>>(transactions);
		for (int i = 0; i < t.size(); i++) {
			if (t.get(i).containsAll(item)) {
				supp++;
			}
		}
		return (double)supp/totNoOfTrans;
	}

	public static Set<Set<String>> generateIndividualItem(Set<Set<String>> transactions) {
		Set<Set<String>> results = new HashSet<Set<String>>();
		ArrayList<Set<String>> t = new ArrayList<Set<String>>(transactions);
		for (int i = 0; i < t.size(); i++) {
			ArrayList<String> tempSet = new ArrayList<String>(t.get(i));
			for (int j = 0; j < tempSet.size(); j++) {
				Set<String> tSet = new HashSet<String>();
				tSet.add(tempSet.get(j));
				results.add(tSet);
			}
		}
		return results;
	}
}
